"""Questão 3 da atividade (Classe Pessoas)"""
class Pessoa:
    """Classe para definir dados sobre pessoas"""

    def __init__(self, nome:str, idade:int) -> None:
        self.nome = nome
        self.idade = idade


    def exibir_detalhes(self):
        """Exibe os dados"""
        print(f"O nome da pessoa é: {self.nome}, a sua idade é: {self.idade}")


def main():
    """Instacia os objetos da classe Pessoa e aplica os métodos"""
    pessoa_1 = Pessoa("Luiz", 18)
    pessoa_2 = Pessoa("Yasmin", 17)

    pessoa_1.exibir_detalhes()
    pessoa_2.exibir_detalhes()

main()
