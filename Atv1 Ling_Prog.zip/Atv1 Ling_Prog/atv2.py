"""Questão 2 da atividade (Calculadora)"""
def main():
    """Instancia os objetos da classe e aplica os métodos"""
    operacao_1 = Calculadora(10, 20)
    operacao_2 = Calculadora(15, 25)
    operacao_3 = Calculadora(20, 30)
    operacao_4 = Calculadora(25, 35)

    for i in (
        operacao_1.somar(),
        operacao_2.subtrair(),
        operacao_3.multiplicar(),
        operacao_4.dividir()
        ):
        print(i)

class Calculadora:
    """Classe com métodos para realizar operações matemáticas]"""
    def __init__(self, numero_1:float, numero_2:float) -> None:
        self.num1 = numero_1
        self.num2 = numero_2


    def somar(self) -> float:
        """Soma os números definidos no objeto"""
        return f"Resultado da soma: {self.num1 + self.num2:.2f}"


    def subtrair(self) -> float:
        """Subtrai os números definidos no objeto"""
        return f"Resultado da subtração: {self.num1 - self.num2:.2f}"


    def multiplicar(self) -> float:
        """Multiplica os números definidos no objeto"""
        return f"Resultado da multiplicação: {self.num1 * self.num2:.2f}"


    def dividir(self) -> float:
        """Divide os números definidos no objeto"""
        if not self.num2 == 0:
            return f"Resultado da divisão: {self.num1 / self.num2:.2f}"
        else:
            raise ValueError("É impossível dividir por 0!")

main()
