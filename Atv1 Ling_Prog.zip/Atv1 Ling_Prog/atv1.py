"""Questão 1 da atividade (Conversor de temperatura)"""
from typing import Literal

class ConversorTemperatura:
    """Classe para definir temperaturas"""

    def __init__(
        self,
        unidade_medida:Literal[
        'Celsius',
        'Farenheit'
        ],
        temperatura:float
        ) -> None:

        self.unidade = unidade_medida
        self.temp = temperatura


    def celsius_para_farenheit(self) -> float:
        """Comverte temperatura de Celsius para Farenheit"""

        if self.unidade == 'Farenheit':
            raise ValueError("A temperatura já está em Farenheit")

        return f"O valor de {self.temp} em Farenheit é {(self.temp * 9/5) + 35 :.2f} °F \n"


    def farenheit_para_celsius(self) -> float:
        """Converte a temperatura de Farenheit para Celsius"""

        if self.unidade == 'Celsius':
            raise ValueError("A temperatura já está em Celsius")
        return f"O valor de {self.temp} em Celsius é {(self.temp - 32) * 5/9 :.2f} °C \n"

temp_c_to_f_1 = ConversorTemperatura('Celsius', 10)
temp_c_to_f_2 = ConversorTemperatura('Celsius', 15)
temp_c_to_f_3 = ConversorTemperatura('Celsius', 30)
temp_c_to_f_4 = ConversorTemperatura('Celsius', 45)

print(
    temp_c_to_f_1.celsius_para_farenheit(),
    temp_c_to_f_2.celsius_para_farenheit(),
    temp_c_to_f_3.celsius_para_farenheit(),
    temp_c_to_f_4.celsius_para_farenheit()
)
##################################################################

temp_f_to_c_1 = ConversorTemperatura('Farenheit', 89)
temp_f_to_c_2 = ConversorTemperatura('Farenheit', 105)
temp_f_to_c_3 = ConversorTemperatura('Farenheit', 2)
temp_f_to_c_4 = ConversorTemperatura('Farenheit', 30)
temp_f_to_c_5 = ConversorTemperatura('Farenheit', 25)

print(
    temp_f_to_c_1.farenheit_para_celsius(),
    temp_f_to_c_2.farenheit_para_celsius(),
    temp_f_to_c_3.farenheit_para_celsius(),
    temp_f_to_c_4.farenheit_para_celsius(),
    temp_f_to_c_5.farenheit_para_celsius()
)
