"""Questão 4 da atividade (Modularização)"""
from pessoa import Pessoa

def main():
    """Instacia os objetos da classe Pessoa e aplica os métodos"""
    pessoa_1 = Pessoa(None, 18)
    pessoa_2 = Pessoa("Yasmin", 17)

    pessoa_1.inserir_nome()

    pessoa_1.exibir_detalhes()
    pessoa_2.exibir_detalhes()

main()
