"""Questão 4 da atividade (Modularização)"""

class Pessoa:
    """Classe para definir dados sobre pessoas"""

    def __init__(self, nome:str | None, idade:int) -> None:
        self.nome = nome
        self.idade = idade


    def inserir_nome(self):
        """Recebe o nome digitado pelo usuário"""
        self.nome = input("Digite seu nome: ")


    def exibir_detalhes(self):
        """Exibe os dados"""
        print(f"O nome da pessoa é: {self.nome}, a sua idade é: {self.idade}")
